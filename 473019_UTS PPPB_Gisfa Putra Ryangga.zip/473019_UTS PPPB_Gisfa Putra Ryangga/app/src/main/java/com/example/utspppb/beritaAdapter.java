package com.example.utspppb;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class beritaAdapter extends RecyclerView.Adapter<beritaAdapter.ViewHolder>{
    private final ArrayList<Berita> listBerita;

    public beritaAdapter(ArrayList<Berita> list){
        this.listBerita = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_berita, viewGroup,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, final int position) {
        final Berita berita = listBerita.get(position);
        holder.txtJudul.setText(berita.getJudul());
        holder.txtAuthor.setText(berita.getAuthor());
        holder.txtIsi.setText(berita.getIsi());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), detailBerita.class);
                Bundle bundle = new Bundle();

                bundle.putString("judul", berita.getJudul());
                bundle.putString("author", berita.getAuthor());
                bundle.putString("isi", berita.getIsi());
                intent.putExtras(bundle);
                v.getContext().startActivity(intent);

                Toast.makeText(holder.itemView.getContext(), "" +
                        listBerita.get(holder.getAdapterPosition()).getJudul(), Toast.LENGTH_SHORT).show();
//                intent.putExtra("judul", berita.judul);
//                intent.putExtra("author", berita.author);
//                intent.putExtra("isi", berita.isi);
//                holder.itemView.getContext().startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return listBerita.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtJudul, txtAuthor, txtIsi;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtJudul = itemView.findViewById(R.id.txt_judul);
            txtAuthor = itemView.findViewById(R.id.txt_author);
            txtIsi = itemView.findViewById(R.id.txt_isi);
        }
    }
}