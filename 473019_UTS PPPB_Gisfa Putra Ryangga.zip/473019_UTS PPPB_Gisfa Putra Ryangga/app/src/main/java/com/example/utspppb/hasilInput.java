package com.example.utspppb;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Objects;

public class hasilInput extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ArrayList<Berita> beritas = new ArrayList<>();
    TextView tv_judul;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hasil_input);

        recyclerView = findViewById(R.id.rv_berita);
        tv_judul = findViewById(R.id.tvJudul);

        //untuk menerima intent dari activity inputData
        Intent intent = getIntent();
        String message = intent.getStringExtra(inputData.MESSAGE_EXTRA);
        int ageData = intent.getIntExtra("kodeUmur", 1);
        tv_judul.setText(message);

        //percabangan untuk menampilkan setiap list data sesuai dengan kategori berita dan umur user
        if(Objects.equals(message, "Film") && ageData < 17){
            beritas.addAll(dataBerita.getListDataMoviesUnder17());
        } else if(Objects.equals(message, "Film") && ageData >= 17){
            beritas.addAll(dataBerita.getListDataMovies());
            beritas.addAll(dataBerita.getListDataMoviesUnder17());
        } else if (Objects.equals(message, "Game") && ageData >= 17 ){
            beritas.addAll(dataBerita.getListDataGame());
            beritas.addAll(dataBerita.getListDataGameUnder17());
        }else if (Objects.equals(message, "Game") && ageData < 17){
            beritas.addAll(dataBerita.getListDataGameUnder17());
        } else if (Objects.equals(message, "Sepakbola") && ageData >= 17 ){
            beritas.addAll(dataBerita.getListDataFootball());
            beritas.addAll(dataBerita.getListDataFootballUnder17());
        }else if (Objects.equals(message, "Sepakbola") && ageData < 17){
            beritas.addAll(dataBerita.getListDataFootballUnder17());
        }
        showRecyclerList();

//        beritaAdapt = new beritaAdapter(this, beritas);
//        recyclerView.setLayoutManager(new LinearLayoutManager(this));
//        recyclerView.setAdapter(beritaAdapt);
    }
    //method untuk menampilkan list recycle view
    private void showRecyclerList(){
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        beritaAdapter beritaAdapt = new beritaAdapter(beritas);
        recyclerView.setAdapter(beritaAdapt);
    }

//    private void addData() {
//        beritas.add(new Berita("Singa", "Oren", "adsfdgfvxc vxcvxcvxcvc"));
//        beritas.add(new Berita("Singa", "Oren", "adsfdgfvxc vxcvxcvxcvc"));
//        beritas.add(new Berita("Singa", "Oren", "adsfdgfvxc vxcvxcvxcvc"));
//        beritas.add(new Berita("Singa", "Oren", "adsfdgfvxc vxcvxcvxcvc"));
//        beritas.add(new Berita("Singa", "Oren", "adsfdgfvxc vxcvxcvxcvc"));
//        beritas.add(new Berita("Singa", "Oren", "adsfdgfvxc vxcvxcvxcvc"));
//        beritas.add(new Berita("Singa", "Oren", "adsfdgfvxc vxcvxcvxcvc"));
//        beritas.add(new Berita("Singa", "Oren", "adsfdgfvxc vxcvxcvxcvc"));
//        beritas.add(new Berita("Singa", "Oren", "adsfdgfvxc vxcvxcvxcvc"));
//
//    }
}