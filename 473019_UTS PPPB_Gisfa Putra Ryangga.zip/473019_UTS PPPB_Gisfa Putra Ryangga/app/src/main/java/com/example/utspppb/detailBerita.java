package com.example.utspppb;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class detailBerita extends AppCompatActivity {
    TextView txtJudul, txtAuthor, txtIsi;
    String judul, author, isi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_berita);

        txtJudul = findViewById(R.id.txt_judul);
        txtAuthor = findViewById(R.id.txt_author);
        txtIsi = findViewById(R.id.txt_isi);

        Bundle bundle = getIntent().getExtras();
        judul = bundle.getString("judul");
        author = bundle.getString("author");
        isi = bundle.getString("isi");


        txtJudul.setText(judul);
        txtAuthor.setText(author);
        txtIsi.setText(isi);
    }
}

//        Intent intent = getIntent();
//
//        judul = intent.getStringExtra("judul");
//        author = intent.getStringExtra("author");
//        isi = intent.getStringExtra("isi");


