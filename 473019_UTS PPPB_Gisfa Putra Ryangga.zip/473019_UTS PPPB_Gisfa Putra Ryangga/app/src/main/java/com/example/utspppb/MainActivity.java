package com.example.utspppb;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText username, password;
    Button submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);
        submit = (Button) findViewById(R.id.buttonSubmit);

        //untuk mengetahui apakah username dan password sudah sesuai
        submit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view){
                String getusername = username.getText().toString();
                String getpassword = password.getText().toString();

                //jika username dan password sesuai, maka akan intent/lanjut ke activity berikutnya yaitu inputData
                if (getusername.equals("pakjoko")&&getpassword.equals("yangpentingcuan")){
                    Intent intent = new Intent(MainActivity.this, inputData.class);
                    startActivity(intent);
                } else{ //jika tidak sesuai, maka harus diisi kembali username dan password yang benar
                    AlertDialog.Builder alertBuilder = new AlertDialog.Builder(MainActivity.this);
                    alertBuilder.setTitle("MAAF, TIDAK DAPAT LOGIN");
                    alertBuilder.setMessage("Username atau password salah, silahkan isi dengan benar!").setNegativeButton("nggih", null);
                    alertBuilder.show();
                }

            }
        });
    }
}